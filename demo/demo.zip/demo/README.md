You'll want to copy your old profile into a new profile, unless you want to
risk corrupting your existing profile data.

1. Start Firefox Developer Edition with the Profile Manager and create a
new profile, in this example - I've named the new profile 'Demo Profile'.
> ![Demo Profile](images/demo_profile.jpg)

2. Next you will want to copy your old profile data into the new
   profile, so quit Firefox.
  
3. Delete all the files and subdirectories in the new profile
   directory.
> <pre>
>     $ cd ~/Library/Application\ Support/Firefox/Profiles
>     $ cd v9xz1d2c.Demo\ Profile/
>     $ rm -rf *
> </pre>

4. Copy all the data from your old profile directory to the new
   profile directory.  In this example, my old profile is called
   'Default User'.
> <pre>
>     $ cp -R ../an5lnccd.Default\ User/* .
> </pre>

5. Start Firefox with the new profile 'Demo Profile'.

6. Go into about:config and disable `xpinstall.signatures.required`
   for installing the new WebExtension API experiment.
> ![about_config](images/about_config.jpg)

7. Drag and drop the experiment.xpi file onto Firefox to initiate 
   installing the experiement addon.

8. Go into `about:debugging` to verify that the `Experimental API` is
   now installed.
> ![experiment_installed](images/experiment_installed.jpg)

8. In `about:debugging` click the `Load Temporary Addon` button to install
   the WebExtension.  You will need to select `package.json` after clicking the
   `Load Temporary Addon` button.
> ![install_packagejson](images/install_packagejson.jpg)

9. Once the WebExtension is loaded, it immediately starts to load the
   profile data.  Clicking on the new Firefox icon in the toolbar will
   give you suggestions based on previous browsing history.  If your
   profile is quite large, it may take a minute or so to load all your
   data.



